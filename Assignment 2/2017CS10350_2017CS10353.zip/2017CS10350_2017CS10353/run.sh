#! /bin/bash
./genematching $1 $2
