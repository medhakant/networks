#! /bin/bash
g++ -o genematching finallocalsearch.cpp
